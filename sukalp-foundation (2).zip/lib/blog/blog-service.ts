import { type BlogSource, blogSources, storageConfig } from "./config"
import type { BlogPost, BlogPostCollection, FetchResult } from "./types"
import { StorageService } from "./storage/storage-service"
import { fetchFromMedium } from "./adapters/medium-adapter"
import { fetchFromWordPress } from "./adapters/wordpress-adapter"

export class BlogService {
  private storageService: StorageService
  private sources: BlogSource[]
  private fetchPromises: Map<string, Promise<FetchResult>> = new Map()

  constructor(sources: BlogSource[] = blogSources, storage = new StorageService(storageConfig)) {
    this.sources = sources
    this.storageService = storage
  }

  /**
   * Fetch posts from a specific source and update local storage
   */
  async fetchAndStoreFromSource(sourceId: string, forceRefresh = false): Promise<BlogPost[]> {
    // Check if we're already fetching this source
    if (this.fetchPromises.has(sourceId)) {
      const result = await this.fetchPromises.get(sourceId)
      return result?.posts || []
    }

    const source = this.sources.find((s) => s.id === sourceId)
    if (!source) {
      throw new Error(`Blog source with ID "${sourceId}" not found`)
    }

    // Check if we have a recent cached version
    if (!forceRefresh) {
      const cachedCollection = await this.storageService.getCollection(sourceId)
      if (cachedCollection && !this.storageService.isCollectionExpired(cachedCollection)) {
        return cachedCollection.posts
      }
    }

    // Create a fetch promise and store it to prevent duplicate fetches
    const fetchPromise = this.fetchFromSource(source)
    this.fetchPromises.set(sourceId, fetchPromise)

    try {
      const result = await fetchPromise

      if (result.success && result.posts) {
        // Store the fetched posts
        const collection: BlogPostCollection = {
          sourceId,
          posts: result.posts,
          lastFetched: Date.now(),
        }

        await this.storageService.saveCollection(collection)
        return result.posts
      } else {
        // If fetch failed, try to return cached posts
        const cachedCollection = await this.storageService.getCollection(sourceId)
        if (cachedCollection) {
          return cachedCollection.posts
        }
        return []
      }
    } finally {
      // Clean up the promise when done
      this.fetchPromises.delete(sourceId)
    }
  }

  /**
   * Fetch posts from all configured sources and update local storage
   */
  async fetchAndStoreFromAllSources(forceRefresh = false): Promise<Map<string, BlogPost[]>> {
    const results = new Map<string, BlogPost[]>()

    await Promise.all(
      this.sources.map(async (source) => {
        try {
          const posts = await this.fetchAndStoreFromSource(source.id, forceRefresh)
          results.set(source.id, posts)
        } catch (error) {
          console.error(`Error fetching from source ${source.id}:`, error)
          results.set(source.id, [])
        }
      }),
    )

    return results
  }

  /**
   * Get posts from local storage for a specific source
   */
  async getPostsFromStorage(sourceId: string): Promise<BlogPost[]> {
    const collection = await this.storageService.getCollection(sourceId)
    return collection?.posts || []
  }

  /**
   * Get all posts from all sources in local storage
   */
  async getAllPostsFromStorage(): Promise<BlogPost[]> {
    const collections = await this.storageService.getAllCollections()
    return collections.flatMap((collection) => collection.posts)
  }

  /**
   * Check if a collection needs to be refreshed
   */
  async needsRefresh(sourceId: string): Promise<boolean> {
    const collection = await this.storageService.getCollection(sourceId)
    if (!collection) return true
    return this.storageService.isCollectionExpired(collection)
  }

  /**
   * Clear local storage for a specific source
   */
  async clearStorage(sourceId: string): Promise<boolean> {
    const result = await this.storageService.clearCollection(sourceId)
    return result.success
  }

  /**
   * Clear all local storage
   */
  async clearAllStorage(): Promise<boolean> {
    const result = await this.storageService.clearAllCollections()
    return result.success
  }

  /**
   * Fetch posts from a source based on its type
   */
  private async fetchFromSource(source: BlogSource): Promise<FetchResult> {
    switch (source.type) {
      case "medium":
        return fetchFromMedium(source)
      case "wordpress":
        return fetchFromWordPress(source)
      case "custom-api":
      case "rss":
        return {
          success: false,
          error: `Source type "${source.type}" not implemented yet`,
        }
      default:
        return {
          success: false,
          error: `Unknown source type: ${(source as any).type}`,
        }
    }
  }
}

// Export a singleton instance for convenience
export const blogService = new BlogService()
