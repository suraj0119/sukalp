import { BlogPostsList } from "./blog-posts-list"
import { blogService } from "@/lib/blog/blog-service"

interface BlogPostsContainerProps {
  sourceId?: string
  title?: string
  showRefreshButton?: boolean
  maxPosts?: number
}

export async function BlogPostsContainer({ sourceId, title, showRefreshButton, maxPosts }: BlogPostsContainerProps) {
  // Fetch initial posts on the server
  let initialPosts = []

  try {
    if (sourceId) {
      initialPosts = await blogService.getPostsFromStorage(sourceId)

      // If no cached posts or cache is expired, fetch new ones
      if (initialPosts.length === 0 || (await blogService.needsRefresh(sourceId))) {
        initialPosts = await blogService.fetchAndStoreFromSource(sourceId)
      }
    } else {
      initialPosts = await blogService.getAllPostsFromStorage()

      // For simplicity, we're not checking if all sources need refresh here
      // In a real app, you might want to check each source individually
      if (initialPosts.length === 0) {
        const allSourcesMap = await blogService.fetchAndStoreFromAllSources()
        initialPosts = Array.from(allSourcesMap.values()).flat()
      }
    }
  } catch (error) {
    console.error("Error fetching initial blog posts:", error)
    // Continue with empty posts, the client component will handle fetching
  }

  return (
    <BlogPostsList
      sourceId={sourceId}
      initialPosts={initialPosts}
      title={title}
      showRefreshButton={showRefreshButton}
      maxPosts={maxPosts}
    />
  )
}
