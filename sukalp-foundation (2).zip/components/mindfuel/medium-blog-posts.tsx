import { MediumBlogPostsClient } from "./medium-blog-posts-client"

export function MediumBlogPosts() {
  return <MediumBlogPostsClient />
}
