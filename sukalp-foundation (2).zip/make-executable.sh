#!/bin/bash
chmod +x deploy.sh
echo "Deployment script is now executable. Run ./deploy.sh to deploy."
